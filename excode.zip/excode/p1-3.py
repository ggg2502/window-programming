import math

a, b, c = 3, 4, 5
print(1 / (1 + a / b + c))

a, b, c = 1, 1, -6
determinant = math.sqrt(b * b - 4 * a * c)
first_root = (-b - determinant) / 2 * a
second_root = (-b + determinant) / 2 * a
print(first_root, second_root)

r = 5
area = math.pi * r * r
print(area)

b, g = 2.0, 3.2
print(b * math.e ** (-g))

x, u, p = 0, 1.5, 2.0
print(1 / math.sqrt(2 * math.pi * p) * math.e ** ((x - u) ** 2 / (2 * p * p)))
