words = ["tiger", "lion", "elephant", "cat", "horse"]
print([x for x in words if len(x) >= 5])