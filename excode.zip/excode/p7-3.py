numbers = [1, 2, 2, 5, 3, 4, 3, 5, 1, 6]
result = [x for i, x in enumerate(numbers) if x not in numbers[:i]]
print(result)