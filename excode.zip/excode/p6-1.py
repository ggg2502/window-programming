class Calc:
    serial = 0
    def __init__(self, a, b):
        self.a = a
        self.b = b
        Calc.serial += 1
        self.serial = Calc.serial

    def add(self):
        return self.a + self.b

    def sub(self):
        return self.a - self.b

    def getSerial(self):
        return self.serial

a = 3
b = 2
calc1 = Calc(a, b)
print(f'{a} + {b} = {calc1.add()}') # "3 + 2 = 5" 출력
print(f'{a} - {b} = {calc1.sub()}') # "3 - 2 = 1" 출력

calc2 = Calc(3, 4)
print(f'{3} + {4} = {calc2.add()}')
print(f'{3} + {4} = {calc2.sub()}')

print(f'Serial of calc1: {calc1.getSerial()}') # 1 출력
print(f'Serial of calc2: {calc2.getSerial()}') # 2 출력