text = "window programm"
print([x for x in text if x not in "aeiouAEIOU"])