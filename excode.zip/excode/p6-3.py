from abc import ABC, abstractmethod

class Polygon(ABC):
    shapes = {3: 'triangle', 4: 'rectangle', 5: 'pentagon'}

    def __init__(self, numSide):
        self.sideNumber = numSide
        self.sideLen = 0

    def setSideLen(self, sideLen):
        self.sideLen = float(sideLen)

    def getShape(self):
        return Polygon.shapes[self.sideNumber]

    @abstractmethod
    def getArea(self):
        pass

class Rectangle(Polygon):
    def __init__(self):
        super().__init__(4)

    def getArea(self):
        return self.sideLen * self.sideLen

if __name__ == "__main__":
    try:
        p = Polygon(4)
    except TypeError as e:
        print(e)
    else:
        raise Exception("It shouldn't be possible to instantiate abstract class Polygon without an implementation for abstract method 'getArea'")

    rectangle = Rectangle()
    rectangle.setSideLen(5)
    print('Area: {}'.format(rectangle.getArea()))