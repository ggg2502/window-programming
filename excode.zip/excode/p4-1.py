def main():
    try:
        with open(input("Filename: ")) as file_in:
            with open(f"{file_in.name}.sav", "w") as file_out:
                file_out.writelines(f"{i} {line}" for i, line in enumerate(file_in, 1))
    except FileNotFoundError:
        print("File not found")
        main()


main()
