def do_operation(func, a, b):
    return func(a, b)

add = lambda a, b: a + b
sub = lambda a, b: a - b

result = do_operation(add, 2, 3)
print(result) # 5
result = do_operation(sub, 2, 3)
print(result) # -1