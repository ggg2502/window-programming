def deco2_add(type):
    match type:
        case "math":
            return lambda f: lambda a, b: f"{a} + {b} = {f(a, b)}"
        case "word":
            return lambda f: lambda a, b: f"The sum of {a} and {b} is {f(a, b)}"
        case _:
            raise ValueError

@deco2_add(type = "math")
def add(a, b):
    return a + b

print(add(2, 4)) # "2 + 4 = 6" 출력

@deco2_add(type = "word")
def add(a, b):
    return a + b

print(add(1, 2)) # "The sum of 1 and 2 is 3" 출력