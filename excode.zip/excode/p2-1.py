a = [1, 0, 1]
b = [1, 1, 2]
out = 0
for i in range(len(a)):
    out += a[i] * b[i]
print(f"{a} * {b} = {out}")
