str = "WindowProgramming"

print(str[1:4]) # ind
print(str[9:]) # gramming
print(str[2:8:2]) # noP
print(str[-1:10:-1]) # gnimma

tup = tuple(str)

print(str[1:4]) # ind
print(str[9:]) # gramming
print(str[2:8:2]) # noP
print(str[-1:10:-1]) # gnimma