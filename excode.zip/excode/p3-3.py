def count_vowel(x: str) -> int:
    return sum(char in "aeiouAEIOU" for char in x)


print(count_vowel(input()))
