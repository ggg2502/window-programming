import math


def calc(*args: int, op: str) -> int:
    match op:
        case "+":
            return sum(args)
        case "*":
            return math.prod(args)
        case _:
            raise ValueError


print(calc(1, 1, 4, op="+"))
print(calc(1, 2, op="*"))
