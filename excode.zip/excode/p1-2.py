x = 10
def test():
    print(x)  # L1: x = 10
test()
print(x)  # L1: x = 10

x = 10
def test():
    x = 20
    print(x)  # L9: x = 20
test()
print(x)  # L7: x = 10
