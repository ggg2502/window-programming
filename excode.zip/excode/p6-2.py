import math
import turtle

from figure import Polygon

class Triangle(Polygon):
    serial = 0
    def __init__(self):
        super().__init__(3)
        Triangle.serial += 1
        self.serial = Triangle.serial

    def getArea(self):
        return math.sqrt(3) / 4 * self.sideLen * self.sideLen

    def getSerial(self):
        return self.serial

    def draw(self):
        for step in range(self.sideNumber):
            turtle.forward(self.sideLen)
            turtle.right(360 / self.sideNumber)
        input("Press any key to stop")

if __name__ == "__main__":
    triangle = Triangle()
    triangle.setSideLen(300)
    print(f"Area of triangle: {triangle.getArea()}")
    print(f"Serial of triangle: {triangle.getSerial()}")
    triangle.draw()