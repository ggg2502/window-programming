def main():
    try:
        s = open(input("Filename: ")).read()
        print(f"characters : {sum(1 for c in s if not c.isspace())}")
        print(f"words      : {len(s.split())}")
        print(f"lines      : {len(s.splitlines())}")
    except FileNotFoundError:
        print("File not found")
        main()


main()
