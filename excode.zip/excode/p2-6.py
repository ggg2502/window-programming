def is_prime(x: int) -> bool:
    if x < 2:
        return False
    for n in range(2, x):
        if x % n == 0:
            return False
    return True


for n in range(1, 101):
    if is_prime(n):
        print(f"{n}은 소수입니다")
