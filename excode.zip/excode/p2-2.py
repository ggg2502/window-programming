dict = {}
while True:
    id = input("id: ")
    if id == "0":
        break
    elif id == "quit":
        exit()
    name = input("name: ")
    if name == "None":
        break
    dict[id] = name
print(dict)

while True:
    id = input("id: ")
    if id == "quit":
        break
    name = dict.get(id)
    if name is None:
        print("not found!")
    else:
        print(name)
