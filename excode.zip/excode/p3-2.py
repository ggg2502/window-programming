from typing import List, Tuple


def min_max(x: List[int]) -> Tuple[int, int]:
    return min(x), max(x)


ints = list(map(int, input().split()))
print("min: {} max: {}".format(*min_max(ints)))
