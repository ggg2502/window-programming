def deco_add(func):
    return lambda a, b: f"{a} + {b} = {func(a, b)}"

@deco_add
def add(a, b):
    return a + b

print(add(2, 4)) # "2 + 4 = 6" 출력