import random


def main():
    wordlist = ["hangman", "window", "programming"]
    word = random.choice(wordlist)
    trials = 6
    game = ["_"] * len(word)
    while True:
        print("".join(game))
        guess = input("guess: ")[0]
        correct = False
        for i, answer in enumerate(word):
            if guess == answer:
                correct = True
                game[i] = answer
        if not correct:
            trials -= 1
            if trials == 0:
                print("Fail!")
                break
            print(f"Nope! {trials} trials left")
            continue
        if not "_" in game:
            print("Good Job!")
            break
    print(f"The word was: {word}")
    choice = input("Continue playing? (y/n): ")
    if choice == "y":
        main()


main()
