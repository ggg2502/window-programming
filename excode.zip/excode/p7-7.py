scores = {
    "Kim": [80, 90, 70],
    "Lee": [100, 90, 85],
    "Park": [95, 85, 100]
}
averages = {k: sum(v) // len(v) for k, v in scores.items()}
print(averages)
names = [k for k, v in averages.items() if v >= 90]
print(names)